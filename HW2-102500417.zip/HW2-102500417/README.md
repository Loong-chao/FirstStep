—— 实验硬件环境
- 运行环境：WSL2 (Ubuntu-22.04)
- CPU：本地x86‑64多核CPU，本实验使用CPU模式运行SGLang，**无GPU**
- 内存：对应本机内存大小

——软件版本信息
- Python版本：3.10
- SGLang版本：填写你的sglang版本 `python -c "import sglang; print(sglang.__version__)"`
- aiohttp、numpy：异步压测与分位数计算依赖
- 虚拟环境：
  1. `sglang_env`：用于启动SGLang推理服务
  2. `ray_env`：用于运行压测脚本（HTTP客户端，不需要启动Ray集群

——安装方法
在WSL中更新系统依赖
sudo apt update
sudo apt install python3 python3-venv python3-pip build-essential

——在venv环境中
安装sglang
 python3 -m venv sglang_env
source ~/sglang_env/bin/activate
pip install --upgrade pip
pip install sglang[all]
开ray环境
 python3 -m venv ray_env
source ray_env/bin/activate
pip install --upgrade pip
pip install aiohttp numpy

——在sglang环境中启动SGL服务
python -m sglang.launch_server \
  --model-path ~/models/Qwen3‑0.6B \
  --host 0.0.0.0 \
  --port 30000 \
  --trust‑remote‑code \
  --device cpu \
  --cuda‑graph‑backend‑prefill disabled \
  --mem‑fraction‑static 0.6 \
  --max‑running‑requests 8

——创建生成负载文件的程序文件
nano gen_workload.py
python3 gen_workload.py
生成了三个文件
shared_prefix_workload.json 共享前缀实验组
warmup_request.json 共享前缀实验组的预热请求，用于后续KV缓存共享
diff_prefix_workload.json 分散前缀对照组

——创建压测脚本
nano run_radix_bench.py

——执行压测脚本
# 1.全局服务预热
python3 run_radix_bench.py service_warmup

# 2.实验组：共享前缀负载，开启前缀预热
python3 run_radix_bench.py exp

# 3.对照组：分散无公共前缀负载，关闭前缀预热
python3 run_radix_bench.py ctrl

——脚本用途说明
1. gen_workload.py
> 生成两组 32 条请求负载：
	 实验组：2048token 公共前缀 + 64token 独有后缀，总长度 2112token，用于触发 RadixCache 前缀复用；
	 对照组：全部请求无公共前缀，无法复用 KV 缓存；单一变量对照实验。

2. run_radix_bench.py
 异步压测脚本，通过 SGLang /generate流式接口发送请求；
 读取服务端返回cached_tokens计算真实缓存命中率；采集每条请求TTFT、TPOT、端到端延迟、actual_prefill_tokens；
 输出：明细.csv，汇总指标_summary.json（成功率、吞吐量、缓存命中率，p50/p95 分位数）。

—— 结果目录与报告表格对应关系
1. exp_result.csv / exp_result_summary.json：共享前缀实验组数据，报告主表【实验组】来源
2. ctrl_result.csv / ctrl_result_summary.json：无公共前缀对照组数据，报告主表【对照组】来源
-summary.json 包含：成功率、吞吐量、缓存命中率、TTFT p50/p95、TPOT p50/p95、端到端延迟 p50/p95。
-csv 保存每条请求明细：input_tokens、output_tokens、status、ttft_s、tpot_s、cached_tokens、actual_prefill_tokens
